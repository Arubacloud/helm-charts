# arubacloud-resource-operator

![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

Kubernetes operator for managing Aruba Cloud resources through CRDs

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| file://../arubacloud-resource-operator-crd | arubacloud-resource-operator-crd | 1.0.0 |
| https://helm.releases.hashicorp.com | vault | 0.32.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| config.auth.idp | string | `"https://mylogin.aruba.it/auth"` |  |
| config.auth.mode | string | `"single"` |  |
| config.auth.multi.setup | string | `"auto"` | How the Vault integration is provisioned. manual: user supplies all vault properties. auto: Vault is installed and configured automatically inside the cluster (dev/demo only). |
| config.auth.multi.vault.address | string | `"http://vault:8200"` |  |
| config.auth.multi.vault.auto | object | `{"devRootToken":"root","helmChartVersion":"0.32.0","namespace":"vault"}` | Settings used only when setup=auto. WARNING: installs Vault in dev mode — NOT for production. |
| config.auth.multi.vault.auto.devRootToken | string | `"root"` | Vault dev root token (used for initial configuration only) |
| config.auth.multi.vault.auto.helmChartVersion | string | `"0.32.0"` | Vault Helm chart version to install |
| config.auth.multi.vault.auto.namespace | string | `"vault"` | Kubernetes namespace where Vault will be deployed |
| config.auth.multi.vault.kvMount | string | `"kv"` |  |
| config.auth.multi.vault.roleId | string | `""` |  |
| config.auth.multi.vault.roleIdFrom.secretKeyRef.key | string | `""` |  |
| config.auth.multi.vault.roleIdFrom.secretKeyRef.name | string | `""` |  |
| config.auth.multi.vault.rolePath | string | `"approle"` |  |
| config.auth.multi.vault.roleSecret | string | `""` |  |
| config.auth.multi.vault.roleSecretFrom.secretKeyRef.key | string | `""` |  |
| config.auth.multi.vault.roleSecretFrom.secretKeyRef.name | string | `""` |  |
| config.auth.realm | string | `"cmp-new-apikey"` |  |
| config.auth.single.clientId | string | `""` |  |
| config.auth.single.clientSecret | string | `""` |  |
| config.gateway | string | `"https://api.arubacloud.com"` |  |
| controller.manager.args[0] | string | `"--metrics-bind-address=:8443"` |  |
| controller.manager.args[1] | string | `"--leader-elect"` |  |
| controller.manager.args[2] | string | `"--health-probe-bind-address=:8081"` |  |
| controller.manager.args[3] | string | `"--config-map-name=$(CONFIG_MAP_NAME)"` |  |
| controller.manager.args[4] | string | `"--secret-name=$(SECRET_NAME)"` |  |
| controller.manager.args[5] | string | `"--namespace=$(POD_NAMESPACE)"` |  |
| controller.manager.containerSecurityContext.allowPrivilegeEscalation | bool | `false` |  |
| controller.manager.containerSecurityContext.capabilities.drop[0] | string | `"ALL"` |  |
| controller.manager.image.repository | string | `"ghcr.io/arubacloud/arubacloud-resource-operator"` |  |
| controller.manager.image.tag | string | `"latest"` |  |
| controller.manager.resources.limits.cpu | string | `"500m"` |  |
| controller.manager.resources.limits.memory | string | `"128Mi"` |  |
| controller.manager.resources.requests.cpu | string | `"10m"` |  |
| controller.manager.resources.requests.memory | string | `"64Mi"` |  |
| controller.nodeSelector | object | `{}` |  |
| controller.podSecurityContext.runAsNonRoot | bool | `true` |  |
| controller.podSecurityContext.seccompProfile.type | string | `"RuntimeDefault"` |  |
| controller.replicas | int | `1` |  |
| controller.tolerations | list | `[]` |  |
| controller.topologySpreadConstraints | list | `[]` |  |
| crds.enabled | bool | `true` |  |
| kubernetesClusterDomain | string | `"cluster.local"` |  |
| metricsService.ports[0].name | string | `"https"` |  |
| metricsService.ports[0].port | int | `8443` |  |
| metricsService.ports[0].protocol | string | `"TCP"` |  |
| metricsService.ports[0].targetPort | int | `8443` |  |
| metricsService.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.automount | bool | `true` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| vault | object | `{"enabled":true,"fullnameOverride":"vault","injector":{"enabled":false},"server":{"dataStorage":{"enabled":false},"dev":{"devRootToken":"root","enabled":true},"enabled":true,"ingress":{"enabled":false},"service":{"enabled":true,"port":8200,"type":"ClusterIP"},"standalone":{"enabled":false}},"ui":{"enabled":true}}` | Vault sub-chart values. Set vault.enabled=true when config.auth.multi.setup=auto. fullnameOverride ensures the Vault service is always reachable at http://vault.<namespace>.svc:8200 regardless of the Helm release name. WARNING: dev mode is enabled by default — NOT for production use. |
| vault.enabled | bool | `true` | Set to true to install Vault as a sub-chart (required for setup=auto) |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.11.0](https://github.com/norwoodj/helm-docs/releases/v1.11.0)
